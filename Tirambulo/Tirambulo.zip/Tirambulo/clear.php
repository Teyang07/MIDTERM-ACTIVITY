<?php
file_put_contents("students.txt", ""); // clears file
echo "<p>🗑️ All student records have been cleared.</p>";
echo "<a href='index.html'>Go Back</a>";
?>